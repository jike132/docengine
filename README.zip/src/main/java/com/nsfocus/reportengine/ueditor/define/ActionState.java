package com.nsfocus.reportengine.ueditor.define;

public enum ActionState {
	UNKNOW_ERROR
}
